# Änderungen

## 1.4.1 — 6. August 2026

**Nachreichen, was beim Sprung auf 1.4.0 liegengeblieben ist.**

- **Der fehlende Portainer-Tab holt sich seine Dateien selbst.** Wer von 1.3.0
  aus aktualisiert hat, bekam `portainer.py` und `portainer_gui.py` nicht mit —
  die alte Fassung kannte diese Namen noch nicht und kopierte nur, was auf
  ihrer Liste stand. Der Tab sagte daraufhin, man solle das Paket von Hand
  holen. Das ist nicht mehr nötig: ein Update von 1.4.0 aus bringt beide
  Dateien mit, und der Knopf im leeren Tab startet es. Nach einem Neustart des
  Programms ist der Tab da.
- **Installieren nimmt die Portainer-Dateien mit.** Beim Kopieren in einen
  festen Ordner blieben sie bisher zurück, mit demselben leeren Tab als Folge.

## 1.4.0 — 6. August 2026

**Zwei Tabs: HAProxy wie bisher, und daneben Portainer.**

- **Oben große Tabs.** Der erste ist das Programm, wie es war — Formular
  links, bestehende Hosts rechts, Protokoll unten. Der zweite ist neu.
- **Portainer-Tab.** Er liest Stacks und Container aus deinem Portainer und
  zeigt zu jedem Stack, **welche Ports er auf dem Host veröffentlicht** — also
  die Ports, die HAProxy ansprechen kann. Ports, die nur an `127.0.0.1`
  hängen, sind als **nur lokal** gekennzeichnet, denn von der Firewall aus
  sind sie nicht erreichbar. Container ohne Stack stehen als eigene Gruppe
  darunter, weil sie dieselben Ports belegen.
- **Vom Port direkt zum Namen.** Steht schon eine HAProxy-Rule auf diesem Port,
  zeigt die Zeile **HAProxy ✓**. Sonst steht dort **→ HAProxy**: ein Klick,
  ein Fenster mit Dienstname, Docker-Host-IP und Port bereits ausgefüllt,
  Basis-Domain und Public Service dazu — angelegt wird dann genau wie im ersten
  Tab, inklusive DNS-Eintrag in AdGuard.
- **Stacks neu deployen**, auf Wunsch mit frisch heruntergeladenen Images
  (das ist das Update) und mit Aufräumen verwaister Container. Stacks aus einem
  Repository und Stacks aus Portainers Editor gehen beide.
- **Neue Stacks aus GitHub oder GitLab.** Name, Branch, Pfad zur Compose-Datei,
  Umgebungsvariablen als Freitext wie bei Portainer, Zugangsdaten für private
  Repositories und automatische Updates — entweder in einem Abstand wie `5m`
  oder über einen Webhook, dessen URL danach im Protokoll steht.
- **Die Variablen aus dem Repository holen.** Der Knopf neben dem ENV-Feld
  liest die Compose-Datei, sammelt jedes `${VAR}` samt Vorgabewert und sucht
  daneben eine `.env` oder `.env.example` — auch die, auf die die Compose-Datei
  mit `env_file:` selbst zeigt. Beides landet vorbereitet im Feld, du passt nur
  noch die Werte an. Getipptes wird dabei nicht überschrieben. Nebenbei ist das
  eine Probe vor dem Deploy: kommt die Compose-Datei zurück, stimmen Adresse,
  Branch, Pfad und Zugangsdaten.
- **Zugangsdaten für private Repositories werden nicht gespeichert.** Sie gehen
  beim Deploy an Portainer, das sie beim Stack hinterlegt; in der
  Konfigurationsdatei dieses Programms stehen sie nicht.
- **Anmeldung wahlweise** über ein Zugriffstoken oder über Benutzer und
  Passwort. Beim Passwort wird das Token bei Bedarf selbst geholt und
  erneuert, wenn es abläuft.
- Beide Hälften gehören zur selben Verbindung: ein Standort hat eine OPNsense
  und einen Portainer, der Umschalter oben schaltet beides um.

Nur Compose-Stacks auf einem einzelnen Docker-Host. Swarm und Kubernetes
werden in der Liste als solche benannt, aber nicht ausgerollt.

## 1.3.0 — 4. August 2026

**Nichts passiert mehr von allein, und man sieht wieder, worauf man drückt.**

- **Beim Start wird nicht mehr verbunden.** Das Fenster geht auf und wartet;
  erst **Verbinden** oben rechts liest Public Services, Zertifikate und
  DNS-Einträge. Danach heißt derselbe Knopf **Neu laden**. Beim Umschalten der
  Verbindung und nach dem Speichern im Zahnrad-Dialog wird weiterhin gelesen —
  das ist ja die Ansage, dass es losgehen soll.
- **Die Knöpfe oben rechts sind Knöpfe geworden**: größer, mit eigener Fläche
  und Rand statt schwebender Zeichen, und die beiden Pfeile nach unten heißen
  jetzt **⇩ Update** und **⤓ Installieren** — vorher waren sie nicht
  auseinanderzuhalten.
- **Die Links springen nicht mehr.** Sie waren unterstrichen, sobald die Maus
  darauf lag, und ein unterstrichener Zeichensatz misst sich anders — die ganze
  Zeile rutschte. Jetzt sind sie durchgehend unterstrichen, und nur die Farbe
  reagiert.
- **Versionsnummer** neben dem Titel und unten rechts am Protokoll, dort
  zusammen mit **DukyNuky** als Verweis aufs Projekt.

Ergänzt in der Anleitung: der API-Benutzer braucht neben *Services: HAProxy*
auch *Services: ACME Client*, sonst bleibt die Liste der Basis-Domains leer.

## 1.2.0 — 4. August 2026

**Ein fester Platz, ein Symbol, und AdGuard im Blick.**

- **Installieren.** Der Knopf **⤓** oben rechts — oder
  `opnsense_haproxy.py install` — kopiert das Programm nach
  `~/.local/share/opnsense-haproxy` (Zielordner frei wählbar), verlinkt die
  Befehle `haproxy-gui` und `opnsense-haproxy` in `~/.local/bin` und trägt es
  ins Anwendungsmenü ein, von wo es sich an die **Taskleiste** anheften lässt.
  Auf Wunsch zusätzlich auf den Schreibtisch. Unter Windows entsteht dieselbe
  Verknüpfung im Startmenü, gestartet über `pythonw.exe` — kein Konsolenfenster
  mehr daneben.
- **Ein Symbol** für Fenster, Taskleiste und Verknüpfung, unter Linux wie unter
  Windows (`icon.png`, `icon.ico`). Gezeichnet von `make_icon.py`, ohne
  Fremdpakete.
- **Die IP von HAProxy** steht jetzt bei der OPNsense, nicht mehr nur bei
  AdGuard: ein Feld `haproxy_ip` pro Verbindung, auf das die DNS-Einträge
  standardmäßig zeigen. Ein `target` im `adguard`-Abschnitt sticht sie weiterhin
  aus, `--dns-target` ebenso. Bestehende Konfigurationen laufen unverändert
  weiter.
- **Die Liste rechts ist anklickbar.** Ein Klick auf den Hostnamen öffnet die
  Seite im Browser — mit dem Schema und dem Port, auf denen der Public Service
  wirklich lauscht.
- **AdGuard pro Eintrag.** Jede Zeile zeigt, ob es eine DNS-Umschreibung gibt
  und ob sie auf HAProxy zeigt; ein Knopf trägt sie ein, biegt sie gerade oder
  löscht sie wieder — ohne HAProxy anzufassen.
- Rules, die in OPNsense von Hand über `hdr_beg` angelegt wurden, werden jetzt
  auch mit Hostnamen erkannt: Link und DNS-Knopf funktionieren für sie.
- Die Knöpfe in der Kopfzeile sagen bei Berührung, wofür sie da sind.

Behoben: Neuere Fassungen des HAProxy-Plugins liefern die Bind-Adresse eines
Public Service als Auswahlfeld statt als Text — im Fenster stand deshalb
Rohdaten-Kauderwelsch statt `192.168.1.1:443`.

## 1.1.0 — 3. August 2026

**Update-Funktion.** Das Programm holt sich neue Fassungen selbst von GitHub.

- Knopf **⇩** oben rechts im Fenster sucht auf Wunsch nach einer neueren
  Version, zeigt Versionsnummer und Änderungstext und installiert sie nach
  Rückfrage. Danach bietet der Dialog den Neustart gleich an.
- Einmal am Tag schaut das Programm beim Start selbst nach — im Hintergrund,
  ohne das Fenster aufzuhalten. Findet es etwas, trägt der Knopf nur die neue
  Versionsnummer; **installiert wird nie von allein.** Ist GitHub nicht
  erreichbar, bleibt das folgenlos. Abschaltbar mit `"update_check": false`
  in `~/.config/opnsense-haproxy/gui.json`.
- Neue Befehle: `opnsense_haproxy.py update [--check] [-y]` und `--version`.

Beim Installieren werden ausschließlich die Programmdateien ersetzt, ausgewählt
über eine feste Namensliste statt über das, was im Archiv steht — aus dem
Download kann damit nichts Fremdes im Ordner landen. Heruntergeladener
Python-Code wird vorher auf Syntax geprüft; ist das Archiv unvollständig oder
beschädigt, wird gar nichts angefasst. Die bisherigen Dateien landen in
`backup-<version>/`. Zugangsdaten und Einstellungen bleiben unangetastet.

Liegt das Programm in einer git-Arbeitskopie, verweigert das Update den Dienst
und verweist auf `git pull`.

## 1.0.0 — 3. August 2026

Erste Fassung.

- Legt aus URL, Server-IP, Port und der SSL-Frage alle vier HAProxy-Objekte auf
  einmal an — Real Server, Backend, Condition und Rule — und hängt die Rule in
  den Public Service. Danach Configtest und Reload.
- Geht ein Schritt schief, werden die bereits angelegten Objekte wieder
  entfernt; es bleibt nichts Halbfertiges stehen.
- **Basis-Domains** kommen aus den Zertifikaten des ACME-Clients, inklusive
  Wildcards. Im Formular reicht dann der Hostname.
- **DNS-Umschreibung in AdGuard Home** wird auf Wunsch gleich mit angelegt und
  beim Entfernen wieder abgeräumt — pro Verbindung einstellbar, und es darf
  auch gar kein AdGuard geben.
- **Mehrere OPNsense** als Verbindungen mit Umschalter oben rechts.
- Fenster (tkinter) und Kommandozeile, hell und dunkel, deutschsprachig.
- `HAProxy-Starter.bat` für Windows: sucht Python, prüft Version und tkinter
  und sagt im Klartext, was fehlt.
- Nur die Python-Standardbibliothek, keine weiteren Pakete.
